1.-copy cntlm and cntlm.conf files to   ~/   folder.
2.-copy cntlmScript.command to Desktop
3.-run in Terminal.app: 
cd Desktop
chmod +x cntlmScript.command
4.-Configure cntlm.conf
5.-Set system proxy to localhost:selectedPort
6.-run cntlmScript.command and you are done.