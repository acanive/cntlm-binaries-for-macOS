Cntlm Installation Manual for Windows
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- Run setup.exe installer
- Edit cntlm.ini
- Start Cntlm

Visit http://cntlm.sf.net for HOWTO's and configuration tips.

Starting and stopping
~~~~~~~~~~~~~~~~~~~~~

You can use Cntlm Start Menu shortcuts to start, stop and configure
the application. Cntlm is installed as an auto-start service.

OR:
Start -> Settings -> Control Panel -> Administrative Tools -> Services

OR (command line):
net start cntlm
net stop cntlm


Uninstalling
~~~~~~~~~~~~
Stop Cntlm service, run uninstaller from your Start Menu, or use
native Windows "Add/Remove Programs" Control Panel.
