#define config_endian 0
#define config_strdup 0
#define config_socklen_t 0
#define config_gethostname 0
